sap.ui.controller("dep.fiori.purchasereq.app.main", {
    onInit: function() {}
});