sap.ui.controller("dep.fiori.transaction.app.main", {
    onInit: function() {}
});