sap.ui.controller("dep.fiori.equipment.app.main", {
    onInit: function() {}
});