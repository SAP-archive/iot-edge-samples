sap.ui.controller("dep.fiori.equipmentmodel.app.main", {
    onInit: function() {}
});