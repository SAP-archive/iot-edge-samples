sap.ui.controller("dep.fiori.incident.app.main", {
    onInit: function() {}
});