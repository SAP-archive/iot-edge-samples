sap.ui.controller("dep.fiori.goodsissuecostcenter.app.main", {
    onInit: function() {}
});