sap.ui.controller("dep.fiori.manifest.app.main", {
    onInit: function() {}
});