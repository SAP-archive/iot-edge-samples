sap.ui.controller("dep.fiori.reportedincidents.app.main", {  
    onInit: function() {}  
});  
