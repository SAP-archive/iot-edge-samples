sap.ui.controller("dep.fiori.report.app.main", {
    onInit: function() {}
});