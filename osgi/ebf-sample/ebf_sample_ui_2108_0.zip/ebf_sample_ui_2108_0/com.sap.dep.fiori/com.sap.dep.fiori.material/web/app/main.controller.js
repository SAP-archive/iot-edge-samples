sap.ui.controller("dep.fiori.material.app.main", {
    onInit: function() {}
});