
jQuery.sap.require("sap.ui.generic.app.AppComponent");
sap.ui.generic.app.AppComponent.extend("dep.fiori.affectedsalesorders.Component", {
	metadata: {
		"manifest": "json"
	}
});
