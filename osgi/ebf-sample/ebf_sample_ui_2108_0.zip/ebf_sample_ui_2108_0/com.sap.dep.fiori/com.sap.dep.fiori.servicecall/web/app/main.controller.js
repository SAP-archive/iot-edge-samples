sap.ui.controller("dep.fiori.servicecall.app.main", {
    onInit: function() {}
});