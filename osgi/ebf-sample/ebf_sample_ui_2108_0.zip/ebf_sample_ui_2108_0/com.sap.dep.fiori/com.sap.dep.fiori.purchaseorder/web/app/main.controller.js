sap.ui.controller("dep.fiori.purchaseorder.app.main", {
    onInit: function() {}
});