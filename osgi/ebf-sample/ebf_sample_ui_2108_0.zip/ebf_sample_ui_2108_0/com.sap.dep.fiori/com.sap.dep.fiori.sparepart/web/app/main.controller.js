sap.ui.controller("dep.fiori.sparepart.app.main", {
    onInit: function() {}
});