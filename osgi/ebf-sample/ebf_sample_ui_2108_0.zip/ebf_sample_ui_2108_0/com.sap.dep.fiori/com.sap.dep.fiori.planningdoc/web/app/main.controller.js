sap.ui.controller("dep.fiori.planningdoc.app.main", {
    onInit: function() {}
});