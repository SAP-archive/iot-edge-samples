sap.ui.controller("dep.fiori.networkgraph.app.main", {  
    onInit: function() {}  
});  
