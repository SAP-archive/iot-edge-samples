sap.ui.controller("dep.fiori.sensorreading.app.main", {
    onInit: function() {}
});