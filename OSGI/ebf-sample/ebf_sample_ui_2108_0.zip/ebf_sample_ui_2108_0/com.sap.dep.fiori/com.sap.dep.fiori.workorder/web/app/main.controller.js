sap.ui.controller("dep.fiori.workorder.app.main", {
    onInit: function() {}
});