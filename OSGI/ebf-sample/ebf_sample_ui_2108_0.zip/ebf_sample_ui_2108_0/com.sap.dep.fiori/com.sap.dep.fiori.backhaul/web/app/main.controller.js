sap.ui.controller("dep.fiori.backhaul.app.main", {
    onInit: function() {}
});