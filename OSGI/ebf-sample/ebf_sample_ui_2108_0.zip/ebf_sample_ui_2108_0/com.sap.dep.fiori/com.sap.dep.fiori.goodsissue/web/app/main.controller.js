sap.ui.controller("dep.fiori.goodsissue.app.main", {
    onInit: function() {}
});