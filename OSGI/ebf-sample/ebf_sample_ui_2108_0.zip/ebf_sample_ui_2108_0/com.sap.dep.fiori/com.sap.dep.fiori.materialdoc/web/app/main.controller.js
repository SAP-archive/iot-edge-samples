sap.ui.controller("dep.fiori.materialdoc.app.main", {
    onInit: function() {}
});