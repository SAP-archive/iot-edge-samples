sap.ui.controller("dep.fiori.notification.app.main", {
    onInit: function() {}
});