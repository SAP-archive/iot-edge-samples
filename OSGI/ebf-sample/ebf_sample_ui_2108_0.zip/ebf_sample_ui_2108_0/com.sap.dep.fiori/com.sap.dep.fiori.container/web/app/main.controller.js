sap.ui.controller("dep.fiori.container.app.main", {
    onInit: function() {}
});