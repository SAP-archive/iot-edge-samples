sap.ui.controller("dep.fiori.transfer.app.main", {
    onInit: function() {}
});