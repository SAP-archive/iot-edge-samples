sap.ui.controller("dep.fiori.inventory.app.main", {
    onInit: function() {}
});