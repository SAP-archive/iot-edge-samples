sap.ui.controller("dep.fiori.wonotification.app.main", {
    onInit: function() {}
});