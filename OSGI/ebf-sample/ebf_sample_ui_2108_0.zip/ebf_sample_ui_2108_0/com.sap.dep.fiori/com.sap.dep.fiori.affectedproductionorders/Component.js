
jQuery.sap.require("sap.ui.generic.app.AppComponent");
sap.ui.generic.app.AppComponent.extend("dep.fiori.affectedproductionorders.Component", {
	metadata: {
		"manifest": "json"
	}
});
