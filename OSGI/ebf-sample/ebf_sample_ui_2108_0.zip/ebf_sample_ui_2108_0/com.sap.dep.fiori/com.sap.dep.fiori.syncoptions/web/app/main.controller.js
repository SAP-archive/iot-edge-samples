sap.ui.controller("dep.fiori.syncoptions.app.main", {
    onInit: function() {}
});
