sap.ui.controller("dep.fiori.syncservices.app.main", {
    onInit: function() {}
});
