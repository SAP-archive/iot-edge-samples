sap.ui.controller("dep.fiori.measuringpoints.app.main", {
    onInit: function() {
    	
    }
});