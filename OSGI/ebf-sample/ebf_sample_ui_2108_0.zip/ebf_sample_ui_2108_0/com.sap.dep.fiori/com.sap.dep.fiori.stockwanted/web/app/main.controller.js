sap.ui.controller("dep.fiori.stockwanted.app.main", {
    onInit: function() {}
});
