sap.ui.controller("dep.fiori.extenderconfig.app.main", {
    onInit: function() {}
});