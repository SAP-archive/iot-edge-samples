sap.ui.controller("dep.fiori.receivegoodswopo.app.main", {
    onInit: function() {}
});