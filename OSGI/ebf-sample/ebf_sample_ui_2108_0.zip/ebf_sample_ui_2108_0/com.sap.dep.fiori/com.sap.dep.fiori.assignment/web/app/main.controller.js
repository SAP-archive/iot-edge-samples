sap.ui.controller("dep.fiori.assignment.app.main", {
    onInit: function() {}
});